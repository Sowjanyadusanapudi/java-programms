
import React from 'react';

function About() {
  return (
    <div>
      <h2>About Foodie Frames</h2>
      <p>This site shares simple, homemade food recipes for food lovers.</p>
    </div>
  );
}

export default About;
