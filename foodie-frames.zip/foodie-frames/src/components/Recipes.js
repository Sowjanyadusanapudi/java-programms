
import React from 'react';

function Recipes() {
  return (
    <div>
      <h2>Homemade Recipes</h2>
      <ul>
        <li>Paneer Butter Masala</li>
        <li>Vegetable Biryani</li>
        <li>Chocolate Cake</li>
      </ul>
    </div>
  );
}

export default Recipes;
