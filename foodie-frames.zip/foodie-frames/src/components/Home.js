
import React from 'react';

function Home() {
  return (
    <div className="text-center">
      <h1>Welcome to Foodie Frames</h1>
      <p>Your destination for delicious homemade recipes!</p>
    </div>
  );
}

export default Home;
