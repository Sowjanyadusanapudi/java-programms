
import React from 'react';

function Contact() {
  return (
    <div>
      <h2>Contact Us</h2>
      <p>Email: support@foodieframes.com</p>
    </div>
  );
}

export default Contact;
